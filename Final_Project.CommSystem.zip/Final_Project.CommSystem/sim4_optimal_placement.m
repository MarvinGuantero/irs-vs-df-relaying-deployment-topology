%%=========================================================================
%% SIMULATION 4: Optimal IRS/Relay Placement
%%=========================================================================
% PURPOSE: Find the placement of IRS/relay along the source-destination
%          axis that MINIMIZES required transmit power. Compare optimal
%          positions for IRS vs. relay.
%
% COMM SYSTEM RELEVANCE: Communication system deployment engineers must
%          decide WHERE to place infrastructure. This simulation finds the
%          placement that maximizes the product of channel gains (betaSR *
%          betaRD), directly optimizing the end-to-end link budget.
%%=========================================================================
set(groot,'defaultFigureColor','white');
set(groot,'defaultAxesColor','white');
config_parameters;

%% Simulation Setup
d1     = 100;                % Source-to-destination horizontal distance
dv     = 10;                 % Vertical offset
Nrange = [50 100 150 200];   % IRS sizes
Rbar   = Rbar_default;

dSR_range = 5:1:95;          % Placement sweep along the axis

SINR    = 2^Rbar - 1;
SINR_DF = 2^(2*Rbar) - 1;
d_SD    = sqrt(d1^2 + dv^2);
betaSD  = pathloss_NLOS(d_SD) * antennaGainS * antennaGainD;

%% Sweep and find optimal placement
P_IRS_sweep = zeros(length(dSR_range), length(Nrange));
P_DF_sweep  = zeros(length(dSR_range), 1);

for k = 1:length(dSR_range)
    d_SR = dSR_range(k);
    d_RD = sqrt((d1 - d_SR)^2 + dv^2);

    if d_RD < 1, d_RD = 1; end

    betaSR = pathloss_LOS(d_SR)  * antennaGainS * antennaGainR;
    betaRD = pathloss_LOS(d_RD)  * antennaGainR * antennaGainD;

    for n = 1:length(Nrange)
        P_IRS_sweep(k,n) = SINR * sigma2 / ...
            (sqrt(betaSD) + Nrange(n)*alpha*sqrt(betaSR*betaRD))^2;
    end

    if betaSR >= betaSD
        P_DF_sweep(k) = SINR_DF * sigma2 * (betaSR + betaRD - betaSD) / ...
            (2 * betaRD * betaSR);
    else
        P_DF_sweep(k) = SINR_DF * sigma2 / betaSD;
    end
end

%% Find optimal positions
[~, idx_DF] = min(P_DF_sweep);
opt_dSR_DF  = dSR_range(idx_DF);

fprintf('\n--- Optimal Placement Results ---\n');
fprintf('  DF Relay optimal d_SR = %d m\n', opt_dSR_DF);

for n = 1:length(Nrange)
    [~, idx] = min(P_IRS_sweep(:,n));
    fprintf('  IRS (N=%3d) optimal d_SR = %d m\n', Nrange(n), dSR_range(idx));
end
fprintf('--------------------------------\n');

%% Plot
figure('Name','Sim4: Optimal Placement','Position',[100 100 800 500]);
hold on; box on; grid on;

plot(dSR_range, 10*log10(P_DF_sweep), 'b-.', 'LineWidth', 2.5);

colors = lines(length(Nrange));
legendEntries = {'DF Relay'};
for n = 1:length(Nrange)
    plot(dSR_range, 10*log10(P_IRS_sweep(:,n)), '-', 'Color', colors(n,:), ...
        'LineWidth', 2);
    legendEntries{end+1} = sprintf('IRS ($N=%d$)', Nrange(n));
end

% Mark optimal points
[minP_DF, idx_DF] = min(P_DF_sweep);
plot(dSR_range(idx_DF), 10*log10(minP_DF), 'bv', 'MarkerSize', 12, ...
    'MarkerFaceColor', 'b', 'LineWidth', 2);

for n = 1:length(Nrange)
    [minP, idx] = min(P_IRS_sweep(:,n));
    plot(dSR_range(idx), 10*log10(minP), 'v', 'Color', colors(n,:), ...
        'MarkerSize', 10, 'MarkerFaceColor', colors(n,:), 'LineWidth', 2);
end

xlabel('IRS/Relay distance from source $d_{SR}$ [m]', 'Interpreter', 'Latex');
ylabel('Minimum required transmit power [dBm]', 'Interpreter', 'Latex');
title('Optimal Placement: Power vs. IRS/Relay Position', 'Interpreter', 'Latex');
legend(legendEntries, 'Location', 'NorthEast', 'Interpreter', 'Latex');
set(gca, 'fontsize', 14);
%%=========================================================================
%% SIMULATION 2: Sweep Vertical Offset (dv)
%%=========================================================================
% PURPOSE: Investigate how the perpendicular offset of the destination
%          from the source-IRS axis affects the IRS vs relay comparison.
%
% COMM SYSTEM RELEVANCE: In real deployments, users are rarely on the
%          direct axis. The vertical offset changes both d_SD and d_RD,
%          altering the link budget geometry. This simulates off-axis users.
%%=========================================================================
set(groot,'defaultFigureColor','white');
set(groot,'defaultAxesColor','white');
config_parameters;

%% Simulation Setup
d1     = 70;
d_SR   = dSR_default;
dv_range = 1:1:80;       % Sweep vertical offset
N      = N_default;
Rbar   = Rbar_default;

SINR    = 2^Rbar - 1;
SINR_DF = 2^(2*Rbar) - 1;

%% Compute metrics vs dv
P_IRS_dv  = zeros(length(dv_range), 1);
P_DF_dv   = zeros(length(dv_range), 1);
P_SISO_dv = zeros(length(dv_range), 1);
SNR_IRS   = zeros(length(dv_range), 1);
SNR_DF    = zeros(length(dv_range), 1);

for k = 1:length(dv_range)
    dv   = dv_range(k);
    d_SD = sqrt(d1^2 + dv^2);
    d_RD = sqrt((d1 - d_SR)^2 + dv^2);

    if d_RD < 1, d_RD = 1; end

    betaSR = pathloss_LOS(d_SR)  * antennaGainS * antennaGainR;
    betaRD = pathloss_LOS(d_RD)  * antennaGainR * antennaGainD;
    betaSD = pathloss_NLOS(d_SD) * antennaGainS * antennaGainD;

    % Transmit powers
    P_SISO_dv(k) = SINR * sigma2 / betaSD;
    P_IRS_dv(k)  = SINR * sigma2 / ...
        (sqrt(betaSD) + N*alpha*sqrt(betaSR*betaRD))^2;

    if betaSR >= betaSD
        P_DF_dv(k) = SINR_DF * sigma2 * (betaSR + betaRD - betaSD) / ...
            (2 * betaRD * betaSR);
    else
        P_DF_dv(k) = SINR_DF * sigma2 / betaSD;
    end

    % SNR (assuming unit transmit power = 1 W = 1000 mW)
    Pt = 1000; % mW
    SNR_IRS(k) = Pt * (sqrt(betaSD) + N*alpha*sqrt(betaSR*betaRD))^2 / sigma2;
    SNR_DF(k)  = Pt * 2 * betaRD * betaSR / (sigma2 * (betaSR + betaRD - betaSD));
end

%% Plot: Transmit Power vs dv
figure('Name','Sim2: Transmit Power vs dv','Position',[100 100 800 500]);
hold on; box on; grid on;


plot(dv_range, 10*log10(P_SISO_dv), 'k--', 'LineWidth', 2);
plot(dv_range, 10*log10(P_DF_dv),   'b-.', 'LineWidth', 2);
plot(dv_range, 10*log10(P_IRS_dv),  'r-',  'LineWidth', 2);

xlabel('Vertical offset $d_v$ [m]', 'Interpreter', 'Latex');
ylabel('Required transmit power [dBm]', 'Interpreter', 'Latex');
title('Impact of Destination Offset on Transmit Power ($N=100$)', ...
    'Interpreter', 'Latex');
legend({'SISO', 'DF Relay', 'IRS (N=100)'}, 'Location', 'NorthWest', ...
    'Interpreter', 'Latex');
set(gca, 'fontsize', 14);

%% Plot: SNR vs dv
figure('Name','Sim2: SNR vs dv','Position',[100 650 800 500]);
hold on; box on; grid on;

plot(dv_range, 10*log10(SNR_IRS), 'r-',  'LineWidth', 2);
plot(dv_range, 10*log10(SNR_DF),  'b-.', 'LineWidth', 2);

xlabel('Vertical offset $d_v$ [m]', 'Interpreter', 'Latex');
ylabel('Received SNR [dB] ($P_t = 1$ W)', 'Interpreter', 'Latex');
title('SNR Comparison: IRS vs. DF Relay for Off-Axis Users', ...
    'Interpreter', 'Latex');
legend({'IRS (N=100)', 'DF Relay'}, 'Location', 'NorthEast', ...
    'Interpreter', 'Latex');
set(gca, 'fontsize', 14);
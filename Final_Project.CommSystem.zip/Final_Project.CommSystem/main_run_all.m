%%=========================================================================
%% MAIN SCRIPT: IRS vs. DF Relay — Topology Extension
%%=========================================================================
% Extension of:
%   Emil Bjornson, Ozgecan Ozdogan, Erik G. Larsson,
%   "Intelligent Reflecting Surface vs. Decode-and-Forward: How Large
%   Surfaces Are Needed to Beat Relaying?,"
%   IEEE Wireless Communications Letters, vol. 9, no. 2, pp. 244-248, 2020.
%
% This extension investigates the impact of IRS/relay PLACEMENT (topology)
% on communication system performance metrics: transmit power, SNR,
% achievable rate, energy efficiency, and outage probability.
%
% Original code: https://github.com/emilbjornson/IRS-relaying
%
% Author: [Your Name]
% Date:   [Date]
%%=========================================================================

close all; clear; clc;

fprintf('============================================================\n');
fprintf(' IRS vs. DF Relay — Topology Extension Simulations\n');
fprintf(' Extending Bjornson et al., IEEE WCL, 2020\n');
fprintf('============================================================\n\n');

%% Run all simulations sequentially
fprintf('>>> [1/6] Sweeping IRS/relay distance from source (d_SR)...\n');
sim1_sweep_dSR;
fprintf('    Done.\n\n');

fprintf('>>> [2/6] Sweeping vertical offset (dv)...\n');
sim2_sweep_dv;
fprintf('    Done.\n\n');

fprintf('>>> [3/6] Monte Carlo random placement...\n');
sim3_montecarlo_random;
fprintf('    Done.\n\n');

fprintf('>>> [4/6] Finding optimal IRS placement...\n');
sim4_optimal_placement;
fprintf('    Done.\n\n');

fprintf('>>> [5/6] Generating 2D heatmap of IRS advantage...\n');
sim5_heatmap_2D;
fprintf('    Done.\n\n');

fprintf('>>> [6/6] Energy efficiency vs topology...\n');
sim6_energy_efficiency_topo;
fprintf('    Done.\n\n');

fprintf('============================================================\n');
fprintf(' All simulations complete. %d figures generated.\n', ...
    length(findobj('Type','figure')));
fprintf('============================================================\n');
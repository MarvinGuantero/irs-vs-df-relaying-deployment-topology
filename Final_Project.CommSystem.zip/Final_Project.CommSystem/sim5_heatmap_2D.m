%%=========================================================================
%% SIMULATION 5: 2D Heatmap — IRS Power Advantage Over Relay
%%=========================================================================
% PURPOSE: Create a 2D heatmap showing the transmit power advantage (in dB)
%          of IRS over DF relay for every possible (x,y) placement of the
%          IRS/relay in a 2D area.
%
% COMM SYSTEM RELEVANCE: This is essentially a COVERAGE MAP — the most
%          fundamental tool in communication system deployment planning.
%          It shows WHERE in the deployment area IRS provides a link budget
%          advantage over relaying.
%%=========================================================================
set(groot,'defaultFigureColor','white');
set(groot,'defaultAxesColor','white');
config_parameters;

%% Simulation Setup
N    = 100;
Rbar = Rbar_default;

source_pos = [0, 0];
dest_pos   = [100, 0];

% Grid resolution
x_grid = 5:2:95;
y_grid = -50:2:50;

SINR    = 2^Rbar - 1;
SINR_DF = 2^(2*Rbar) - 1;

d_SD   = norm(dest_pos - source_pos);
betaSD = pathloss_NLOS(d_SD) * antennaGainS * antennaGainD;

%% Compute power advantage on grid
powerAdv_dB = zeros(length(y_grid), length(x_grid));

for i = 1:length(y_grid)
    for j = 1:length(x_grid)
        pos = [x_grid(j), y_grid(i)];

        d_SR = norm(pos - source_pos);
        d_RD = norm(pos - dest_pos);

        if d_SR < 1, d_SR = 1; end
        if d_RD < 1, d_RD = 1; end

        betaSR = pathloss_LOS(d_SR) * antennaGainS * antennaGainR;
        betaRD = pathloss_LOS(d_RD) * antennaGainR * antennaGainD;

        % IRS power
        P_IRS = SINR * sigma2 / ...
            (sqrt(betaSD) + N*alpha*sqrt(betaSR*betaRD))^2;

        % DF power
        if betaSR >= betaSD
            P_DF = SINR_DF * sigma2 * (betaSR + betaRD - betaSD) / ...
                (2 * betaRD * betaSR);
        else
            P_DF = SINR_DF * sigma2 / betaSD;
        end

        % Advantage: positive means IRS is better
        powerAdv_dB(i,j) = 10*log10(P_DF) - 10*log10(P_IRS);
    end
end

%% Plot Heatmap
figure('Name','Sim5: 2D Heatmap','Position',[100 100 900 550]);

imagesc(x_grid, y_grid, powerAdv_dB);
set(gca, 'YDir', 'normal');
colormap(jet);
cb = colorbar;
ylabel(cb, 'IRS power advantage over DF relay [dB]', 'Interpreter', 'Latex', ...
    'FontSize', 13);
hold on;

% Contour at 0 dB (break-even boundary)
contour(x_grid, y_grid, powerAdv_dB, [0 0], 'k-', 'LineWidth', 2.5);

% Mark source and destination
plot(source_pos(1), source_pos(2), 'ws', 'MarkerSize', 16, ...
    'MarkerFaceColor', 'w', 'LineWidth', 2);
plot(dest_pos(1), dest_pos(2), 'w^', 'MarkerSize', 16, ...
    'MarkerFaceColor', 'w', 'LineWidth', 2);

text(source_pos(1)+2, source_pos(2)+4, 'Source', 'Color', 'w', ...
    'FontSize', 12, 'FontWeight', 'bold');
text(dest_pos(1)-15, dest_pos(2)+4, 'Dest', 'Color', 'w', ...
    'FontSize', 12, 'FontWeight', 'bold');

xlabel('$x$ [m]', 'Interpreter', 'Latex');
ylabel('$y$ [m]', 'Interpreter', 'Latex');
title(sprintf('IRS ($N=%d$) Power Advantage Over DF Relay — Deployment Heatmap', N), ...
    'Interpreter', 'Latex');
set(gca, 'fontsize', 14);
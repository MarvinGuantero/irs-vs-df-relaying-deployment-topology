%%=========================================================================
%% SHARED CONFIGURATION: System Parameters
%%=========================================================================
% All simulation scripts call this file to ensure consistent parameters.
% Based on the 3GPP Urban Micro (UMi) model used in Bjornson et al., 2020.
%%=========================================================================

%% Communication System Parameters

% Carrier frequency (in GHz)
fc = 3;

% Bandwidth (Hz)
B = 10e6;

% Noise figure (in dB)
noiseFiguredB = 10;

% Compute noise power in mW
sigma2dBm = -174 + 10*log10(B) + noiseFiguredB;
sigma2 = db2pow(sigma2dBm);

%% Antenna Gains (linear scale)
antennaGainS = db2pow(5);   % Source antenna gain
antennaGainR = db2pow(5);   % Relay/IRS antenna gain
antennaGainD = db2pow(0);   % Destination antenna gain

%% 3GPP Urban Micro Path Loss Models (TS 36.814)
% LOS:  PL(d) = 28 + 20*log10(fc) + 22*log10(d)
% NLOS: PL(d) = 22.7 + 26*log10(fc) + 36.7*log10(d)
pathloss_LOS  = @(x) db2pow(-28   - 20*log10(fc) - 22*log10(x));
pathloss_NLOS = @(x) db2pow(-22.7 - 26*log10(fc) - 36.7*log10(x));

%% IRS Parameters
alpha = 1;          % Amplitude reflection coefficient (ideal)
N_default = 100;    % Default number of IRS reflecting elements

%% Energy Efficiency Parameters
Ps = 100;   % Source hardware power dissipation (mW)
Pd = 100;   % Destination hardware power dissipation (mW)
Pe = 5;     % Power dissipation per IRS element (mW)
Pr = 100;   % Relay hardware power dissipation (mW)
nu = 0.5;   % Power amplifier efficiency

%% Default Geometry
d1_default  = 70;   % Horizontal distance source-to-destination (m)
dv_default  = 10;   % Vertical offset of destination from source-IRS axis (m)
dSR_default = 80;   % Distance source-to-IRS/relay (m)

%% Target Rate
Rbar_default = 4;   % Target rate (bit/s/Hz)
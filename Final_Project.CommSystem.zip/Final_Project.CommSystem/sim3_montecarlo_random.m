%%=========================================================================
%% SIMULATION 3: Monte Carlo Random Placement
%%=========================================================================
% PURPOSE: Randomly place the IRS/relay in a 2D area and compute the
%          probability that IRS outperforms DF relaying across many
%          random deployment scenarios.
%
% COMM SYSTEM RELEVANCE: Real-world deployments have uncertainty in node
%          placement. This Monte Carlo analysis answers: "What fraction of
%          random deployments favor IRS over relaying?" — a statistical
%          coverage/outage analysis fundamental to comm system planning.
%%=========================================================================
set(groot,'defaultFigureColor','white');
set(groot,'defaultAxesColor','white');
config_parameters;

%% Simulation Setup
numTrials  = 10000;         % Number of Monte Carlo realizations
Nrange     = [50 100 150];  % IRS sizes to test
Rbar       = Rbar_default;

% Source at origin, destination at fixed location
source_pos = [0, 0];
dest_x     = 100;           % Destination x-coordinate (m)
dest_y     = 0;             % Destination y-coordinate (m)
dest_pos   = [dest_x, dest_y];

% IRS/relay placement area (rectangular region between source and dest)
x_min = 10;  x_max = 90;
y_min = -50; y_max = 50;

SINR    = 2^Rbar - 1;
SINR_DF = 2^(2*Rbar) - 1;

%% Monte Carlo Loop
P_IRS_mc = zeros(numTrials, length(Nrange));
P_DF_mc  = zeros(numTrials, 1);
P_SISO_mc = zeros(numTrials, 1);
irs_x    = zeros(numTrials, 1);
irs_y    = zeros(numTrials, 1);

rng(42); % For reproducibility

for trial = 1:numTrials
    % Random IRS/relay position
    rx = x_min + (x_max - x_min) * rand();
    ry = y_min + (y_max - y_min) * rand();
    irs_x(trial) = rx;
    irs_y(trial) = ry;

    % Compute distances
    d_SR = sqrt((rx - source_pos(1))^2 + (ry - source_pos(2))^2);
    d_RD = sqrt((rx - dest_pos(1))^2   + (ry - dest_pos(2))^2);
    d_SD = sqrt((dest_pos(1))^2        + (dest_pos(2))^2);

    if d_SR < 1, d_SR = 1; end
    if d_RD < 1, d_RD = 1; end

    % Channel gains
    betaSR = pathloss_LOS(d_SR)  * antennaGainS * antennaGainR;
    betaRD = pathloss_LOS(d_RD)  * antennaGainR * antennaGainD;
    betaSD = pathloss_NLOS(d_SD) * antennaGainS * antennaGainD;

    % SISO
    P_SISO_mc(trial) = SINR * sigma2 / betaSD;

    % IRS for each N
    for n = 1:length(Nrange)
        P_IRS_mc(trial,n) = SINR * sigma2 / ...
            (sqrt(betaSD) + Nrange(n)*alpha*sqrt(betaSR*betaRD))^2;
    end

    % DF relay
    if betaSR >= betaSD
        P_DF_mc(trial) = SINR_DF * sigma2 * (betaSR + betaRD - betaSD) / ...
            (2 * betaRD * betaSR);
    else
        P_DF_mc(trial) = SINR_DF * sigma2 / betaSD;
    end
end

%% Compute probability that IRS beats DF relay
prob_IRS_wins = zeros(1, length(Nrange));
for n = 1:length(Nrange)
    prob_IRS_wins(n) = sum(P_IRS_mc(:,n) < P_DF_mc) / numTrials * 100;
end

%% Plot 1: Probability Bar Chart
figure('Name','Sim3: Prob IRS Beats Relay','Position',[100 100 600 450]);
bar(Nrange, prob_IRS_wins, 0.5, 'FaceColor', [0.2 0.6 0.9]);
xlabel('Number of IRS elements $N$', 'Interpreter', 'Latex');
ylabel('Probability IRS beats DF relay [\%]', 'Interpreter', 'Latex');
title('Monte Carlo: Fraction of Random Topologies Where IRS Wins', ...
    'Interpreter', 'Latex');
set(gca, 'fontsize', 14);
ylim([0 105]);
grid on; box on;

% Add text labels on bars
for n = 1:length(Nrange)
    text(Nrange(n), prob_IRS_wins(n)+2, sprintf('%.1f%%', prob_IRS_wins(n)), ...
        'HorizontalAlignment', 'center', 'FontSize', 13, 'FontWeight', 'bold');
end

%% Plot 2: Scatter — placement colored by which system wins (N=100)
n_idx = find(Nrange == 100);
irs_wins = P_IRS_mc(:, n_idx) < P_DF_mc;

figure('Name','Sim3: Scatter IRS vs Relay','Position',[750 100 700 550]);
hold on; box on; grid on;

scatter(irs_x(~irs_wins), irs_y(~irs_wins), 8, [0.8 0.2 0.2], 'filled', ...
    'MarkerFaceAlpha', 0.4);
scatter(irs_x(irs_wins),  irs_y(irs_wins),  8, [0.2 0.6 0.2], 'filled', ...
    'MarkerFaceAlpha', 0.4);

% Mark source and destination
plot(source_pos(1), source_pos(2), 'ks', 'MarkerSize', 14, ...
    'MarkerFaceColor', 'k', 'LineWidth', 2);
plot(dest_pos(1), dest_pos(2), 'k^', 'MarkerSize', 14, ...
    'MarkerFaceColor', 'k', 'LineWidth', 2);

xlabel('$x$ position [m]', 'Interpreter', 'Latex');
ylabel('$y$ position [m]', 'Interpreter', 'Latex');
title('IRS Placement Map: Green = IRS wins, Red = Relay wins ($N=100$)', ...
    'Interpreter', 'Latex');
legend({'Relay wins', 'IRS wins', 'Source', 'Destination'}, ...
    'Location', 'SouthWest', 'Interpreter', 'Latex');
set(gca, 'fontsize', 14);

%% Plot 3: CDF of power savings
powerSaving_dB = 10*log10(P_DF_mc) - 10*log10(P_IRS_mc(:,n_idx));

figure('Name','Sim3: CDF Power Saving','Position',[100 650 700 450]);
hold on; box on; grid on;

[f, x_cdf] = ecdf(powerSaving_dB);
plot(x_cdf, f, 'r-', 'LineWidth', 2);
xline(0, 'k--', 'LineWidth', 1.5);

xlabel('Power saving of IRS over DF relay [dB]', 'Interpreter', 'Latex');
ylabel('CDF', 'Interpreter', 'Latex');
title('CDF of Transmit Power Savings ($N=100$, random topology)', ...
    'Interpreter', 'Latex');
legend({'CDF', '$P_{IRS} = P_{DF}$ boundary'}, 'Location', 'SouthEast', ...
    'Interpreter', 'Latex');
set(gca, 'fontsize', 14);
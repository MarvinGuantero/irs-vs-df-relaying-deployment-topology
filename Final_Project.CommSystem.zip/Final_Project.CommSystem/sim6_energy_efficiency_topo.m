%%=========================================================================
%% SIMULATION 6: Energy Efficiency vs. Topology
%%=========================================================================
% PURPOSE: Compare energy efficiency (bits/Joule) of IRS, DF relay, and
%          SISO across different IRS/relay placements. Show how topology
%          affects the GREEN COMMUNICATION metric.
%
% COMM SYSTEM RELEVANCE: Energy efficiency is a key 5G/6G KPI. This
%          simulation shows that WHERE you place the IRS determines whether
%          it is more energy-efficient than a relay — a critical result for
%          sustainable communication system design.
%%=========================================================================
set(groot,'defaultFigureColor','white');
set(groot,'defaultAxesColor','white');
config_parameters;

%% Simulation Setup
Rbar_range = 0.01:0.1:10;  % Rate sweep
dSR_values = [40 60 80];   % Three different placements to compare
d1 = 100;
dv = 10;
N  = N_default;

%% Compute EE for each topology
EE_IRS_topo  = zeros(length(Rbar_range), length(dSR_values));
EE_DF_topo   = zeros(length(Rbar_range), length(dSR_values));
EE_SISO      = zeros(length(Rbar_range), 1);

d_SD   = sqrt(d1^2 + dv^2);
betaSD = pathloss_NLOS(d_SD) * antennaGainS * antennaGainD;

for t = 1:length(dSR_values)
    d_SR = dSR_values(t);
    d_RD = sqrt((d1 - d_SR)^2 + dv^2);

    betaSR = pathloss_LOS(d_SR)  * antennaGainS * antennaGainR;
    betaRD = pathloss_LOS(d_RD)  * antennaGainR * antennaGainD;

    for ind = 1:length(Rbar_range)
        Rbar = Rbar_range(ind);
        SINR    = 2^Rbar - 1;
        SINR_DF = 2^(2*Rbar) - 1;

        % SISO (same for all topologies)
        P_SISO = SINR * sigma2 / betaSD;
        EE_SISO(ind) = 1000 * B * Rbar / (P_SISO/nu + Ps + Pd);

        % Optimal N for IRS (Eq. from original paper)
        Nopt = (2*SINR*sigma2 / (nu*alpha^2*betaSR*betaRD*Pe))^(1/3) ...
            - sqrt(betaSD/(betaSR*betaRD)) / alpha;
        if Nopt < 0, Nopt = 0; end

        % IRS
        P_IRS = SINR * sigma2 / ...
            (sqrt(betaSD) + Nopt*alpha*sqrt(betaSR*betaRD))^2;
        EE_IRS_topo(ind,t) = 1000 * B * Rbar / ...
            (P_IRS/nu + Ps + Pd + Nopt*Pe);

        % DF relay
        if betaSR >= betaSD
            P_DF = SINR_DF * sigma2 * (betaSR + betaRD - betaSD) / ...
                (2 * betaRD * betaSR);
        else
            P_DF = SINR_DF * sigma2 / betaSD;
        end
        EE_DF_topo(ind,t) = 1000 * B * Rbar / ...
            (P_DF/nu + Ps/2 + Pd + Pr);
    end
end

%% Plot: EE vs Rate for Different Topologies
figure('Name','Sim6: Energy Efficiency vs Topology','Position',[100 100 900 550]);
hold on; box on; grid on;

% SISO baseline
plot(Rbar_range, EE_SISO/1e6, 'k--', 'LineWidth', 2);

colors_irs = [1 0 0; 0.8 0.2 0; 0.6 0 0];
colors_df  = [0 0 1; 0 0.4 0.8; 0.2 0.2 0.6];
legendEntries = {'SISO (direct)'};

for t = 1:length(dSR_values)
    plot(Rbar_range, EE_IRS_topo(:,t)/1e6, '-', 'Color', colors_irs(t,:), ...
        'LineWidth', 2);
    legendEntries{end+1} = sprintf('IRS ($d_{SR}=%d$ m)', dSR_values(t));
end
for t = 1:length(dSR_values)
    plot(Rbar_range, EE_DF_topo(:,t)/1e6, '-.', 'Color', colors_df(t,:), ...
        'LineWidth', 2);
    legendEntries{end+1} = sprintf('DF ($d_{SR}=%d$ m)', dSR_values(t));
end

xlabel('Achievable rate [bit/s/Hz]', 'Interpreter', 'Latex');
ylabel('Energy efficiency [Mbit/Joule]', 'Interpreter', 'Latex');
title('Energy Efficiency: IRS vs. DF Relay at Different Placements', ...
    'Interpreter', 'Latex');
legend(legendEntries, 'Location', 'NorthEast', 'Interpreter', 'Latex', ...
    'NumColumns', 2);
set(gca, 'fontsize', 14);

%% Print summary
fprintf('\n--- Peak Energy Efficiency Summary ---\n');
fprintf('  %-25s  Peak EE [Mbit/J]\n', 'Configuration');
fprintf('  %-25s  %.2f\n', 'SISO', max(EE_SISO)/1e6);
for t = 1:length(dSR_values)
    fprintf('  IRS  (d_SR = %3d m)       %.2f\n', dSR_values(t), ...
        max(EE_IRS_topo(:,t))/1e6);
    fprintf('  DF   (d_SR = %3d m)       %.2f\n', dSR_values(t), ...
        max(EE_DF_topo(:,t))/1e6);
end
fprintf('-------------------------------------\n');
%%=========================================================================
%% SIMULATION 1: Sweep IRS/Relay Distance from Source (d_SR)
%%=========================================================================
% PURPOSE: Show how moving the IRS/relay along the source-destination axis
%          affects transmit power for SISO, IRS, and DF relay.
%
% COMM SYSTEM RELEVANCE: Path loss is the dominant factor in link budget.
%          Changing d_SR directly changes channel gains beta_SR and beta_RD,
%          which determine the SNR and required transmit power.
%%=========================================================================

config_parameters;

%% Simulation Setup
d1 = 100;                   % Fixed destination horizontal distance (m)
dv = dv_default;            % Vertical offset (m)
dSR_range = 10:2:150;       % Sweep IRS/relay position along the axis
Nrange = [50 100 150];      % Different IRS sizes to compare
Rbar = Rbar_default;

% Derived
SINR    = 2^Rbar - 1;
SINR_DF = 2^(2*Rbar) - 1;
d_SD    = sqrt(d1^2 + dv^2);
betaSD  = pathloss_NLOS(d_SD) * antennaGainS * antennaGainD;

%% Compute transmit power vs d_SR
P_SISO = SINR * sigma2 / betaSD * ones(length(dSR_range),1);
P_IRS  = zeros(length(dSR_range), length(Nrange));
P_DF   = zeros(length(dSR_range), 1);

for k = 1:length(dSR_range)
    d_SR = dSR_range(k);
    d_RD = sqrt((d1 - d_SR)^2 + dv^2);

    % Ensure minimum distance of 1m to avoid singularity
    if d_RD < 1, d_RD = 1; end
    if d_SR < 1, d_SR = 1; end

    betaSR = pathloss_LOS(d_SR) * antennaGainS * antennaGainR;
    betaRD = pathloss_LOS(d_RD) * antennaGainR * antennaGainD;

    % IRS transmit power (Eq. 12 from original paper)
    for n = 1:length(Nrange)
        P_IRS(k,n) = SINR * sigma2 / ...
            (sqrt(betaSD) + Nrange(n)*alpha*sqrt(betaSR*betaRD))^2;
    end

    % DF relay transmit power (Eq. 14 from original paper)
    if betaSR >= betaSD
        P_DF(k) = SINR_DF * sigma2 * (betaSR + betaRD - betaSD) / ...
            (2 * betaRD * betaSR);
    else
        P_DF(k) = SINR_DF * sigma2 / betaSD;
    end
end

%% Plot Results
figure('Name','Sim1: Transmit Power vs d_SR', ...
       'Position',[100 100 800 500], ...
       'Color','w');
hold on; box on; grid on;

plot(dSR_range, 10*log10(P_SISO), 'k--', 'LineWidth', 2);
plot(dSR_range, 10*log10(P_DF),   'b-.', 'LineWidth', 2);

colors = [1 0 0; 0.8 0 0.2; 0.6 0 0.4];
legendEntries = {'SISO (direct)', 'DF Relay'};
for n = 1:length(Nrange)
    plot(dSR_range, 10*log10(P_IRS(:,n)), '-', 'Color', colors(n,:), ...
        'LineWidth', 2);
    legendEntries{end+1} = sprintf('IRS (N=%d)', Nrange(n));
end

xlabel('IRS/Relay distance from source, $d_{SR}$ [m]', 'Interpreter', 'Latex');
ylabel('Required transmit power [dBm]', 'Interpreter', 'Latex');
title('Impact of IRS/Relay Placement on Transmit Power', 'Interpreter', 'Latex');
legend(legendEntries, 'Location', 'NorthEast', 'Interpreter', 'Latex');
set(gca, 'fontsize', 14);